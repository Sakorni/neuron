﻿using System;
using System.Collections.Generic;

namespace NeuralNetwork1
{

    class Neuron
    {
        // Activation function
        private double NeuronActivation(double x)
        {
            return 1.0 / (1.0 + Math.Exp(-x));
        }
        public double ActivationDerivative(double x)
        {
            return x * (1 - x);
        }
        public double Output;
        // На каком слое этот нейрон находится
        public int layer;
        // Ошибка нейрона
        public double error;
        // 0 - "фейковый" нейрон, остальное - веса с предыдущего слоя
        public double[] prevLayerWeights;

        public void SetInput(double x)
        {
            if (layer == 0)
            {
                Output = x;
            }
            else
            {
                Output = NeuronActivation(x);
            }
        }
        public Neuron(int layer, int prevLayerCap, Random random)
        {
            this.layer = layer;
            if (layer == -1)
            { // fake layer
                Output = 1;
            }
            if (layer < 1)
            {
                prevLayerWeights = null;
                return;
            }

            prevLayerWeights = new double[prevLayerCap];
            for (int i = 0; i < prevLayerCap; i++)
            {
                prevLayerWeights[i] = random.NextDouble(); // Случайные связи да...
            }
        }

        public class StudentNetwork : BaseNetwork
        {
            private double learningRate = 0.1;

            private double biasValue;
            private Neuron[][] layers;

            public StudentNetwork(int[] structure)
            {
                if (structure.Length < 3)
                {
                    throw new Exception("Structure must have at least 3 inputs");
                }
                Random rand = new Random();

                biasValue = 1;

                layers = new Neuron[structure.Length][];
                layers[0] = new Neuron[structure[0]];
                for (int i = 0; i < structure[0]; i++)
                {
                    layers[0][i] = new Neuron(-1, -1, rand); // bias connections
                }
                for (int i = 1; i < structure.Length; i++)
                {
                    layers[i] = new Neuron[structure[i]];
                    for (int j = 0; j < structure[i]; j++)
                    {
                        layers[i][j] = new Neuron(i, structure[i - 1], rand);
                    }
                }
            }

            private void propagationForward(double[] inputs)
            {
                if (inputs.Length != layers[0].Length)
                {
                    throw new Exception("Input vector must have the same length as the network structure");
                }
                for (int i = 0; i < inputs.Length; i++)
                {
                    layers[0][i].SetInput(inputs[i]);
                }
                for (int layer = 1; layer < layers.Length; layer++)
                {
                    for (int neuron = 0; neuron < layers[layer].Length; neuron++) // TODO Parallel
                    {
                        // Считаем скалярное произведение от предыдущих нейрончиков
                        double scalar = 0;
                        // foreach (var prevNeuron in layers[layer - 1])
                        // {
                        //     scalar += layers[layer][nN].Output * weights[layers[layer][nN].id][layers[layer][neuron].id];
                        // }
                        //
                        // // Добавялем к этому произведению bias
                        // scalar += layers[layer][nN].Output * weights[layers[layer][nN].id][layers[layer][neuron].id];

                        for (int i = 0; i < layers[layer][neuron].prevLayerWeights.Length; i++)
                        {
                            // Обрабатываем bias
                            if (i == 0)
                            {
                                scalar += biasValue * layers[layer][neuron].prevLayerWeights[0];
                                continue;
                            }

                            // Страшно, но как есть - на предыдущем слое нейроны o..Length, в векторе весов нашего нейрона - 1..Length+1
                            scalar += layers[layer - 1][i - 1].Output * layers[layer][neuron].prevLayerWeights[i];
                        }

                        // Получили наш вход
                        layers[layer][neuron].SetInput(scalar);
                    }
                }
            }

            public void backwardPropagation(Sample sample)
            {
                var aim = sample.Output;
                var lastLayer = layers.Length - 1;
                // Для выходного слоя применяем производную лосс-функции
                for (var i = 0; i < layers[lastLayer].Length; i++)
                {
                    layers[lastLayer][i].error = LossFunctionDerivative(layers[lastLayer][i].Output, aim[i]);
                }

                for (int layer = layers.Length - 1; layer >= 1; layer--)
                {
                    for (var nN = 0; nN < layers[layer].Length; nN++) // NeuronNumber
                    {
                        // Применяем производную функции активации
                        layers[layer][nN].error *= layers[layer][nN].ActivationDerivative(layers[layer][nN].Output);

                        // // Считаем страшную сумму ошибок для предыдущего слоя и меняем веса
                        // foreach (var prevNeuron in layers[layer - 1])
                        // {
                        //     layers[layer][nN].error += layers[layer][nN].error * weights[layers[layer][nN].id][layers[layer][nN].id];
                        //     weights[layers[layer][nN].id][layers[layer][nN].id] += learningRate * layers[layer][nN].error * layers[layer][nN].Output;
                        // }
                        //
                        // // Нельзя забывать про малыша bias!!!
                        // layers[layer][nN].error += layers[layer][nN].error * weights[layers[layer][nN].id][layers[layer][nN].id];
                        // weights[layers[layer][nN].id][layers[layer][nN].id] += learningRate * layers[layer][nN].error * layers[layer][nN].Output;

                        for (int i = 0; i < layers[layer][nN].prevLayerWeights.Length; i++)
                        {
                            // Нельзя забывать про малыша bias!!!
                            if (i == 0)
                            {
                                // biasValue.error += layers[layer][nN].error * layers[layer][nN].prevLayerWeights[0];
                                layers[layer][nN].prevLayerWeights[0] += learningRate * layers[layer][nN].error * biasValue;
                                continue;
                            }

                            layers[layer - 1][i - 1].error += layers[layer][nN].error * layers[layer][nN].prevLayerWeights[i];
                            layers[layer][nN].prevLayerWeights[i] += learningRate * layers[layer][nN].error * layers[layer - 1][i - 1].Output;
                        }

                        // Мы прогнали ошибку дальше, откатываемся к изначальному виду
                        layers[layer][nN].error = 0;
                    }
                }
            }

            public override int Train(Sample sample, double acceptableError, bool parallel)
            {
                int count = 0;
                while (true)
                {
                    count++;
                    propagationForward(sample.input);
                    if (LossFunction(getLastArrayOutput(), sample.Output) <= acceptableError || count > 50)
                    {
                        return count;
                    }
                    backwardPropagation(sample);
                }
            }
            private double[] getLastArrayOutput()
            {
                var lastLayer = layers[layers.Length - 1];
                var ret = new double[lastLayer.Length];
                int i = 0;
                foreach (var neuron in lastLayer)
                {
                    ret[i] = neuron.Output;
                    i++;
                }
                return ret;
            }
            double TrainOnSample(Sample sample, double acceptableError)
            {
                double loss;
                propagationForward(sample.input);
                loss = LossFunction(getLastArrayOutput(), sample.Output);
                backwardPropagation(sample);
                return loss;
            }
            public override double TrainOnDataSet(SamplesSet samplesSet, int epochsCount, double acceptableError, bool parallel)
            {
                var start = DateTime.Now;
                int totalSamplesCount = epochsCount * samplesSet.Count;
                int processedSamplesCount = 0;
                double sumError = 0;
                double mean;
                for (int epoch = 0; epoch < epochsCount; epoch++)
                {
                    for (var indexinside = 0; indexinside < samplesSet.samples.Count; indexinside++)
                    {
                        var sample = samplesSet.samples[indexinside];
                        sumError += TrainOnSample(sample, acceptableError);

                        processedSamplesCount++;
                        if (indexinside % 100 == 0)
                        {
                            // Выводим среднюю ошибку для обработанного
                            OnTrainProgress(1.0 * processedSamplesCount / totalSamplesCount,
                                sumError / (epoch * samplesSet.Count + indexinside + 1), DateTime.Now - start);
                        }
                    }

                    mean = sumError / ((epoch + 1) * samplesSet.Count + 1);
                    if (mean <= acceptableError)
                    {
                        OnTrainProgress(1.0,
                            mean, DateTime.Now - start);
                        return mean;
                    }
                }
                mean = sumError / (epochsCount * samplesSet.Count + 1);
                OnTrainProgress(1.0,
                           mean, DateTime.Now - start);
                return sumError / (epochsCount * samplesSet.Count);
            }

            protected override double[] Compute(double[] input)
            {
                if (input.Length != layers[0].Length)
                {
                    throw new ArgumentException("У вас тут данных многовато...");
                }

                propagationForward(input);
                return getLastArrayOutput();
            }

            private double LossFunction(double[] real, double[] expected)
            {
                double res = 0;
                for (var i = 0; i < expected.Length; i++)
                {
                    res += Math.Pow(expected[i] - real[i], 2);
                }
                return res * 0.5;
            }
            private double LossFunctionDerivative(double real, double expected)
            {
                return expected - real;
            }
        }
    }
}